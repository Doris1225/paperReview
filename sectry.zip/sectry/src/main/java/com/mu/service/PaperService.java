package com.mu.service;

import com.mu.entity.Papers;

import java.util.List;

public interface PaperService {

    void addPaper(Papers papers);

    //Papers queryPaperById(Long paperId);

    List<Papers> queryAllPaper();

    List<Papers> queryAllUploaded();
}
