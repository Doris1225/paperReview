package com.mu.mapper;

import com.mu.entity.Papers;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import java.util.List;

@Mapper
public interface PaperMapper {

    //[C] create a paper
    @Select("insert into mu.paper('paperName', 'paperAuthorID', 'paperDate')\n" +
            "        values(#{paperName},#{paperAuthorID},#{paperDate});")
    @Options(useGeneratedKeys = true,keyProperty = "paperId")
    void addPaper(Papers papers);

    //2int deletePaperById(@Param("paperID") int id);

    //3int updatePaper(Papers papers);

    //query one paper
    //@Select("select * from mu.paper where paperId=#{paperId}")
    //Papers queryPaper(Long paperId);

    //query all papers
    @Select("select * from mu.paper")
    List<Papers> queryAllPaper();

    @Select("select * from mu.paper where paperAuthorID=#{paperAuthorID}")
    List<Papers> queryAllUploaded();

    //
    //5Papers queryPaperByName(@Param("paperName") String paperName);

}

