package com.mu.service;

import com.mu.mapper.PaperMapper;
import com.mu.entity.Papers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PaperServiceImpl implements PaperService {

    //service tier invoke mapper tier
    @Autowired
    PaperMapper paperMapper;

    public void addPaper(Papers papers){
        paperMapper.addPaper(papers);
    }

     /**
    public int deletePaperById(int id){
        return paperMapper.deletePaperById(id);
    }

    public int updatePaper(Papers papers){
        return paperMapper.updatePaper(papers);
    }

     */

     /*
    public Papers queryPaperById(Long paperId){
        return paperMapper.queryPaper(paperId);
    }
*/
    public List<Papers> queryAllPaper(){
        return paperMapper.queryAllPaper();
    }

    public List<Papers> queryAllUploaded() {
        return paperMapper.queryAllUploaded();
    }

    /*
    public Papers queryPaperByName(String paperName){
        return paperMapper.queryPaperByName(paperName);
    }
     */
}

