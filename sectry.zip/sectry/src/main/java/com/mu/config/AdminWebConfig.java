package com.mu.config;

import com.mu.interceptor.LoginInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 拦截器的实现：
 * 1.编写一个拦截器，实现HandlerInterceptor接口
 * 2.把拦截器注册到容器中。（实现WebMvcConfigurer的addInterceptors）
 * 3.note：要指定拦截规则。别忘放行静态资源（除非是精确拦截）
 */
@Configuration
public class AdminWebConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry){
        //添加一个拦截器
        registry.addInterceptor(new LoginInterceptor())
                .addPathPatterns("/**")  // Intercept all requests
                .excludePathPatterns("/","/login","/css/**","/images/**","/fonts/**","/js/**");

    }
}
