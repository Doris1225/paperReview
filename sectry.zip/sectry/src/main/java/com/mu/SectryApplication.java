package com.mu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@MapperScan("com.mu.mapper")
@SpringBootApplication
public class SectryApplication {

    public static void main(String[] args) {
        SpringApplication.run(SectryApplication.class, args);
    }

}
