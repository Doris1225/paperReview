package com.mu.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

@Data
public class Users {
    private String userName;
    private String password;

    //the 3 below is the database's 字段
    private Long userID;
    private Integer userTab;  //标记，0为root用户，1为老师，2为学生
/**
    public Long getuserID() {
        return userID;
    }
    public void setuserID(Long id) {
        this.userID = id;
    }

    public Integer getuserTab() {
        return userTab;
    }
    public void setuserTab(Integer tab) {
        this.userTab = tab;
    }

    public String getuserName() {
        return userName;
    }
    public void setuserName(String username) {
        this.userName = username;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
*/
}





