package com.mu.controller;

import com.mu.entity.Users;
import com.mu.service.PaperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpSession;

@Controller
@Slf4j
public class IndexController {
    @Autowired
    PaperService paperService;
    /*

    @ResponseBody
    @PostMapping("/createPape")
    public Papers createPaper(Papers papers){
        paperService.addPaper(papers);
        return papers;
    }

*/

    //去登录页
    @GetMapping(value={"/","/login"})
    public String loginPage(){
        return "login";
    }

    //enter dashboard(index.html)
    @PostMapping("/login")
    public String main(Users users, HttpSession session, Model model){

        if(StringUtils.hasLength(users.getUserName()) && StringUtils.hasLength(users.getPassword())){
            //把登录成功的用户保存起来
            session.setAttribute("loginUser",users);
            //登录成功,重定向到index.html。以防止表单重复提交

            return "redirect:/index.html";
        }else {
            model.addAttribute("msg","userID or password wrong!");
            //back to login page
            return "login";
        }
    }

    //重定向到index页面（当刷新时，重新提交表单,只做这个方法）
    @GetMapping("/index.html")
    public String indexPage(HttpSession session,Model model){

        log.info("当前方法是：{}","indexPage");
        //judge whether login successfully, avoid illegal access
        //拦截器，过滤器 机制
        Object loginUser = session.getAttribute("loginUser");
        if(loginUser != null){
            return "index";
        }else{
            //back to login page
            model.addAttribute("msg","please login again!");
            return "login";
        }
    }
}
