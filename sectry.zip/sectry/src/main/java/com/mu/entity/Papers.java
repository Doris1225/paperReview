
//实体类

package com.mu.entity;

import lombok.Data;
import java.util.Date;

@Data
public class Papers {
    private Long paperId;
    private String paperName;
    private Integer paperAuthorID;
    private Date paperDate;
    private String paperKeyword;
    private Integer decision;
    private String comments;
}
