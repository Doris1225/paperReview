package com.mu;


import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

@Slf4j
@SpringBootTest
class SectryApplicationTests {

    @Autowired
    JdbcTemplate jdbcTemplate;

    //@Autowired
    //UserMapper userMapper;

    @Test
    void contextLoads() {
        /**
        jdbcTemplate.queryForObject("select * from paper");
        jdbcTemplate.queryForList("select * from paper");
        Long aLong = jdbcTemplate.queryForObject("select count(*) from paper",Long.class);
        System.out.println();
        log.info("记录总数：{}",aLong);
         */
    }

    /**
    @Test
    void testUserMapper(){
        Users users = userMapper.selectById(1);
        //System.out.println();
        log.info("用户信息：{}",users);
    }
    */
}
