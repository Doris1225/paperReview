
package com.mu.controller;

import com.mu.entity.Papers;
import com.mu.service.PaperService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@Controller
public class TableController {

    @Autowired
    PaperService paperService;

    @GetMapping("/showall.html")
    public String list(Model model){
        Collection<Papers> papers = paperService.queryAllPaper();
        model.addAttribute("papers",papers);
        return "showall";
    }

    @GetMapping("/upload.html")
    public String uploadA(Papers papers){
        return "upload";
    }


    @GetMapping("/uploaded.html")
    public String list_uploaded(Model model_uploaded){
        Collection<Papers> papers = paperService.queryAllUploaded();
        model_uploaded.addAttribute("papers_uploaded",papers);
        return "uploaded";
    }

    @RequestMapping("paperUpload")
    @ResponseBody
    public String paperUpload(@RequestParam("paperName") Papers papers){
        /*
        if(papers.isEmpty()){
            return "this file is empty";
        }

        String path = "F:/test" ;//文件保存路径
        File targetFile = new File(path + "/" + fileName);
        if(!targetFile.getParentFile().exists()){ //判断文件父目录是否存在
            targetFile.getParentFile().mkdir();
        }
        try {
            file.transferTo(targetFile); //保存文件
            return "upload file success";
        } catch (IllegalStateException e) {
            e.printStackTrace();
            return "upload file fail";
        } catch (IOException e) {
            e.printStackTrace();
            return "upload file fail";
        }
        */
        System.out.println("!!!");
        return "!";
    }
}


